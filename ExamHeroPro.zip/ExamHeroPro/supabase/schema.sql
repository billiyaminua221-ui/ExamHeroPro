-- Run this in Supabase Dashboard > SQL Editor.
-- The app's signed-in users can read/write only their own progress row.

create table if not exists public.progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"history":[]}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.progress enable row level security;
drop policy if exists "Users can read their own progress" on public.progress;
create policy "Users can read their own progress" on public.progress
  for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert their own progress" on public.progress;
create policy "Users can insert their own progress" on public.progress
  for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update their own progress" on public.progress;
create policy "Users can update their own progress" on public.progress
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  premium_until timestamptz,
  paystack_reference text,
  updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;
drop policy if exists "Users can read their own subscription" on public.subscriptions;
create policy "Users can read their own subscription" on public.subscriptions
  for select to authenticated using (auth.uid() = user_id);
-- No client insert/update policies: only trusted server code using service role can grant Premium.

create table if not exists public.payments (
  reference text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_days integer not null check (plan_days in (30, 90)),
  created_at timestamptz not null default now()
);
alter table public.payments enable row level security;
-- No user-facing policies on payments. It is accessed only by trusted server code.

create or replace function public.activate_premium(
  p_user_id uuid,
  p_reference text,
  p_plan_days integer
)
returns table(premium_until timestamptz, already_activated boolean)
language plpgsql
security definer
set search_path = public
as $$
declare
  inserted_count integer;
  current_until timestamptz;
  new_until timestamptz;
begin
  -- Serialize activations for one student, including the first subscription.
  perform 1 from auth.users where id = p_user_id for update;

  if p_plan_days not in (30, 90) then
    raise exception 'Invalid plan duration';
  end if;

  insert into public.payments(reference, user_id, plan_days)
  values (p_reference, p_user_id, p_plan_days)
  on conflict (reference) do nothing;

  get diagnostics inserted_count = row_count;
  if inserted_count = 0 then
    return query select s.premium_until, true
      from public.subscriptions s where s.user_id = p_user_id;
    return;
  end if;

  select s.premium_until into current_until
  from public.subscriptions s where s.user_id = p_user_id for update;

  new_until := greatest(coalesce(current_until, now()), now()) + make_interval(days => p_plan_days);

  insert into public.subscriptions(user_id, premium_until, paystack_reference, updated_at)
  values (p_user_id, new_until, p_reference, now())
  on conflict (user_id) do update set
    premium_until = excluded.premium_until,
    paystack_reference = excluded.paystack_reference,
    updated_at = excluded.updated_at;

  return query select new_until, false;
end;
$$;

revoke all on function public.activate_premium(uuid, text, integer) from public, anon, authenticated;
grant execute on function public.activate_premium(uuid, text, integer) to service_role;
