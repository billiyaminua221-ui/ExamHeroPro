# ExamHero Pro Privacy Policy — TEMPLATE

**This is a starting template, not legal advice. Replace every bracketed item and have the policy reviewed for the laws and markets where you operate before publishing.**

Effective date: [DATE]

ExamHero Pro is operated by [LEGAL NAME / BUSINESS NAME] (“we”, “us”). Contact: [SUPPORT EMAIL].

## Information we process
- Account details such as email address and account identifier when you register or sign in.
- Study progress, scores and practice history that you choose to save.
- Subscription status and payment reference information needed to confirm Premium. Card/payment credentials are handled by Paystack; we do not intentionally store full card details.
- Topic prompts sent for AI-generated practice questions when you use that feature.
- Basic technical data processed by our hosting, database and service providers for security and operation.

## How we use information
We use this information to provide accounts, save progress, deliver practice questions, activate paid subscriptions, respond to support requests, prevent fraud and maintain the service.

## Providers
The service may use Supabase for authentication/database, Vercel for hosting, Paystack for payments, and Anthropic for AI-generated questions. These providers process data as needed to provide their services under their own terms and privacy policies.

## Retention and security
We retain information while needed to operate the service, meet legal/accounting duties, resolve disputes and enforce agreements. We use access controls and server-side secret storage, but no online service can promise absolute security.

## Children
[Describe the intended age range, parental consent process if applicable, and how younger users can request deletion. Do not launch until this section matches your actual policy and local law.]

## Your choices and requests
To request access, correction or deletion of your account information, contact [SUPPORT EMAIL]. Some information may need to be retained for legal, security or payment-record reasons.

## Changes
We may update this policy and will post the revised version with a new effective date.
