# ExamHero Pro — deployment guide (beginner-friendly)

You can do most setup from an Android phone, although a laptop makes file and dashboard work easier. Keep the ZIP private until you have tested it. Do not send anyone your secret keys or passwords.

## 1. Create Supabase (accounts and saved results)

1. Create a project at https://supabase.com and save its database password privately.
2. Open **Project Settings → API** (or the API Keys page in the current dashboard).
3. Copy the project URL and the public/anon key. These are the values for `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Copy the **service role** key for server use only. Put it in Vercel as `SUPABASE_SERVICE_ROLE_KEY`. Never put this key in `src/App.jsx`, any `VITE_` variable, a screenshot, or a public message.
5. Open **SQL Editor**, create a new query, paste all of `supabase/schema.sql`, and run it.
6. Open **Authentication → Providers → Email** and ensure Email is enabled. Configure email confirmation and a real SMTP provider before opening registration to the public. For a private first test, you can temporarily disable confirmation in Auth settings.

## 2. Create provider keys

- **Paystack:** create your business/project in https://paystack.com. Start with a TEST secret key. The secret key belongs only in Vercel as `PAYSTACK_SECRET_KEY`.
- **Anthropic:** create an API key in https://console.anthropic.com. Add it in Vercel as `ANTHROPIC_API_KEY`. AI usage may incur charges; set provider usage limits where available.

Never paste these secret keys into ChatGPT messages, public GitHub, screenshots, or any variable starting with `VITE_`.

## 3. Deploy to Vercel

1. Extract this ZIP and upload the project to a **private** GitHub repository (or use a deployment flow that keeps the code private).
2. Open https://vercel.com, import that repository, and deploy it as a Vite project.
3. In Vercel **Project → Settings → Environment Variables**, add these values for Production (and Preview if needed):

| Variable | Value |
|---|---|
| `VITE_USE_BACKEND` | `true` |
| `VITE_SUPABASE_URL` | your Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | your Supabase public/anon key |
| `VITE_DEV_PREMIUM` | `false` |
| `SUPABASE_URL` | same Supabase project URL |
| `SUPABASE_ANON_KEY` | same public/anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service-role secret |
| `PAYSTACK_SECRET_KEY` | Paystack TEST secret key first |
| `ANTHROPIC_API_KEY` | your Anthropic API key |
| `APP_URL` | full deployed site URL, e.g. `https://your-project.vercel.app` |
| `ANTHROPIC_MODEL` | optional; defaults to `claude-haiku-5-5` |

4. Redeploy after adding or changing environment variables. Vite variables are compiled into the website, so the `VITE_` values require a rebuild.

## 4. Test before accepting money

- Create a test student account and sign in/out.
- Complete practice questions, refresh the page, and confirm local history remains.
- Confirm progress syncs when signed in and that each user can only read their own progress/subscription.
- Open Premium: use Paystack TEST keys and test cards/instructions shown by Paystack's official test mode. Confirm a failed/cancelled transaction does not activate Premium.
- Complete a successful test payment and confirm the subscription is activated only after `/api/paystack-verify` verifies it.
- Try calling AI without Premium; the server must deny it. With Premium and an Anthropic key, generate questions and review them for accuracy.
- Check that Premium does not activate if amount, currency, reference, account email, or user metadata do not match.
- Check the website on Android at a narrow screen size.

Only after the test flow passes should you replace the Paystack TEST key with a LIVE secret key in Vercel and redeploy. Ensure the Paystack business/account is fully enabled for live payments.

## 5. App limitations to resolve before public launch

- Ads are not integrated. To monetize with ads, register with a supported ad network, use its approved placement IDs, implement required privacy/consent disclosures, and test mobile behavior.
- The current bank of questions is small and should be expanded and independently reviewed. They are not official past papers.
- Add a support email, privacy policy, terms, refund/cancellation policy, and clear pricing before collecting public payments.
- Consider rate limiting and monitoring for public API endpoints, and configure Supabase backups/usage alerts.
- The current client stores the session/progress in browser storage. For a public production service, review session-storage security and add a proper account recovery/support flow.
- This project is a web app. To publish a native Android app, additional PWA/Android packaging and Play Store steps are needed.

## Troubleshooting

- **Payments say not connected:** confirm all Vercel environment variables, `VITE_USE_BACKEND=true`, and redeploy.
- **Sign-up works but sign-in fails:** check Supabase email confirmation and SMTP/auth settings.
- **AI returns unavailable:** check `ANTHROPIC_API_KEY`, usage/billing, the selected model and Vercel function logs.
- **Paystack verification cannot activate Premium:** check `SUPABASE_SERVICE_ROLE_KEY`, that `supabase/schema.sql` ran successfully, and the Vercel function logs. Never manually grant Premium to a payment that has not been verified by Paystack.
