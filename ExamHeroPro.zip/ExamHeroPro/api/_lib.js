const PLAN_CONFIG = {
  monthly: { priceNaira: 1500, days: 30, name: 'Monthly' },
  term: { priceNaira: 3500, days: 90, name: 'Exam season' },
};

export function json(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  return res.json(body);
}

export async function readBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') {
    try { return JSON.parse(req.body); } catch { return {}; }
  }
  let raw = '';
  for await (const chunk of req) raw += chunk;
  try { return JSON.parse(raw || '{}'); } catch { return {}; }
}

export function env(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing server environment variable: ${name}`);
  return value;
}

export async function requireUser(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) {
    const error = new Error('Sign in is required.'); error.status = 401; throw error;
  }
  const base = env('SUPABASE_URL').replace(/\/$/, '');
  const anon = env('SUPABASE_ANON_KEY');
  const r = await fetch(`${base}/auth/v1/user`, {
    headers: { apikey: anon, Authorization: `Bearer ${token}` },
  });
  const user = await r.json().catch(() => ({}));
  if (!r.ok || !user.id || !user.email) {
    const error = new Error('Your session is invalid or expired. Please sign in again.'); error.status = 401; throw error;
  }
  return user;
}

export async function adminRest(path, options = {}) {
  const base = env('SUPABASE_URL').replace(/\/$/, '');
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  const r = await fetch(`${base}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });
  const text = await r.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }
  if (!r.ok) {
    const error = new Error(data?.message || data?.hint || 'Database request failed.');
    error.status = 502; throw error;
  }
  return data;
}

export async function isPremium(userId) {
  const rows = await adminRest(`subscriptions?select=premium_until&user_id=eq.${encodeURIComponent(userId)}&limit=1`);
  return !!(rows?.[0]?.premium_until && Date.parse(rows[0].premium_until) > Date.now());
}

export function planById(id) { return PLAN_CONFIG[id] || null; }
