import { env, json, readBody, requireUser, isPremium } from './_lib.js';

function cleanQuestions(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 12).filter((q) =>
    q && typeof q.q === 'string' && q.q.trim() &&
    Array.isArray(q.options) && q.options.length === 4 &&
    q.options.every((o) => typeof o === 'string' && o.trim()) &&
    Number.isInteger(q.a) && q.a >= 0 && q.a <= 3 && typeof q.why === 'string'
  ).map((q) => ({ q: q.q.trim().slice(0, 500), options: q.options.map(o => o.trim().slice(0, 250)), a: q.a, why: q.why.trim().slice(0, 500) }));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed.' });
  try {
    const user = await requireUser(req);
    if (!(await isPremium(user.id))) return json(res, 403, { error: 'AI topic practice is a Premium feature.' });
    const { topic, count = 8, exam = 'practice' } = await readBody(req);
    if (typeof topic !== 'string' || topic.trim().length < 2 || topic.length > 180) {
      return json(res, 400, { error: 'Enter a topic between 2 and 180 characters.' });
    }
    const safeCount = Math.max(1, Math.min(8, Number.isFinite(Number(count)) ? Number(count) : 8));
    const examNames = { practice: 'general Nigerian secondary-school practice', waec: 'WAEC/WASSCE-style', neco: 'NECO/SSCE-style', jamb: 'JAMB/UTME-style' };
    const examName = examNames[exam] || examNames.practice;
    const prompt = `Create ${safeCount} original multiple-choice study questions for Nigerian students about: ${topic.trim()} (${examName}). Return ONLY valid JSON, no markdown, using this exact shape: [{"q":"question","options":["A","B","C","D"],"a":0,"why":"short explanation"}]. Each question must have exactly four options, one correct answer, and a zero-based answer index 0-3. Do not claim these are official past questions. Keep explanations concise.`;
    const apiKey = env('ANTHROPIC_API_KEY');
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-haiku-5-5', max_tokens: 2200, messages: [{ role: 'user', content: prompt }] }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) return json(res, 502, { error: payload.error?.message || 'AI provider request failed.' });
    const raw = (payload.content || []).filter(x => x.type === 'text').map(x => x.text).join('').replace(/```json|```/g, '').trim();
    let parsed;
    try { parsed = JSON.parse(raw); } catch { return json(res, 502, { error: 'The AI returned an unreadable response. Please try again.' }); }
    const questions = cleanQuestions(parsed);
    if (!questions.length) return json(res, 502, { error: 'No valid questions were generated. Try a more specific topic.' });
    return json(res, 200, { questions });
  } catch (e) {
    return json(res, e.status || 500, { error: e.status ? e.message : 'AI service is temporarily unavailable.' });
  }
}
