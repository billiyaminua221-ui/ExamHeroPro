import { env, json, readBody, requireUser, planById } from './_lib.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed.' });
  try {
    const user = await requireUser(req);
    const { plan: planId } = await readBody(req);
    const plan = planById(planId);
    if (!plan) return json(res, 400, { error: 'Choose a valid Premium plan.' });
    const appUrl = env('APP_URL').replace(/\/$/, '');
    const response = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env('PAYSTACK_SECRET_KEY')}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: user.email,
        amount: plan.priceNaira * 100,
        currency: 'NGN',
        callback_url: `${appUrl}/`,
        metadata: { user_id: user.id, plan_id: planId, plan_name: plan.name },
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.status || !payload.data?.authorization_url) {
      return json(res, 502, { error: payload.message || 'Could not start Paystack checkout.' });
    }
    return json(res, 200, { authorization_url: payload.data.authorization_url, reference: payload.data.reference });
  } catch (e) {
    return json(res, e.status || 500, { error: e.status ? e.message : 'Payment service is temporarily unavailable.' });
  }
}
