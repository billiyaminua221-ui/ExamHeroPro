import { env, json, readBody, requireUser, planById, adminRest } from './_lib.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { error: 'Method not allowed.' });
  try {
    const user = await requireUser(req);
    const { reference } = await readBody(req);
    if (typeof reference !== 'string' || reference.length < 8 || reference.length > 120) {
      return json(res, 400, { error: 'Invalid payment reference.' });
    }
    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${env('PAYSTACK_SECRET_KEY')}` },
    });
    const payload = await response.json().catch(() => ({}));
    const txn = payload.data;
    if (!response.ok || !payload.status || !txn) return json(res, 502, { error: payload.message || 'Could not verify payment.' });
    const planId = txn.metadata?.plan_id;
    const plan = planById(planId);
    const sameEmail = String(txn.customer?.email || '').toLowerCase() === String(user.email).toLowerCase();
    const sameUser = txn.metadata?.user_id === user.id;
    if (txn.status !== 'success' || !plan || !sameEmail || !sameUser || Number(txn.amount) !== plan.priceNaira * 100 || txn.currency !== 'NGN') {
      return json(res, 400, { error: 'Payment could not be matched to this account and plan. Contact support if you were charged.' });
    }
    // A database function handles duplicate references atomically, so reloading
    // the callback cannot grant the same paid plan twice.
    const activated = await adminRest('rpc/activate_premium', {
      method: 'POST',
      body: JSON.stringify({ p_user_id: user.id, p_reference: reference, p_plan_days: plan.days }),
    });
    const row = Array.isArray(activated) ? activated[0] : activated;
    if (!row?.premium_until) return json(res, 502, { error: 'Payment was verified but Premium could not be activated. Contact support with your reference.' });
    return json(res, 200, { premium_until: row.premium_until, already_activated: !!row.already_activated });
  } catch (e) {
    return json(res, e.status || 500, { error: e.status ? e.message : 'Payment verification is temporarily unavailable.' });
  }
}
