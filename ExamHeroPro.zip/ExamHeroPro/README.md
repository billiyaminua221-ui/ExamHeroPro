# ExamHero Pro

A mobile-friendly Nigerian exam-practice web app for WAEC, NECO, JAMB and free practice. This package keeps the original ExamHero Pro React interface and adds a Vite project wrapper plus secure server-side API routes for AI practice and Paystack Premium payments.

## Included

- Existing dark navy/gold UI and question-bank practice
- Mathematics, English, Science and General Knowledge subject areas from the supplied source
- Explanations, scores/history, daily free-round limit and JAMB 30-second timer
- Supabase email/password accounts and cloud progress
- Secure server-side Anthropic AI question generation (Premium required)
- Paystack checkout for ₦1,500 / 30 days and ₦3,500 / 90 days
- Payment verification against Paystack, the signed-in user, amount, currency and plan
- SQL schema with row-level security and idempotent Premium activation

## Important before launch

This is a deployable project scaffold, not a claim that your live service is already connected. You must create your own Supabase, Anthropic and Paystack accounts, set the environment variables, run the SQL, and test with Paystack test keys before accepting real money. No secret keys are included. The app currently has no advertising network integration; ad accounts/IDs and consent/privacy requirements must be added separately if you want ads.

## Quick local preview

Requires Node.js 20+ and internet access for installing packages.

```bash
npm install
cp .env.example .env.local
npm run dev
```

The UI can be previewed without backend credentials, but accounts, cloud sync, AI generation and payments will not work until configured. Do not enable the free Premium preview on a public production site.

## Production setup

Follow `DEPLOY_GUIDE.md` carefully. In short:

1. Create a Supabase project and run `supabase/schema.sql` in SQL Editor.
2. Enable Email auth in Supabase. For first testing, you may turn email confirmation off; for a public service, configure SMTP/email confirmation properly.
3. Deploy this repository to Vercel.
4. Add the environment variables listed in `DEPLOY_GUIDE.md` to Vercel. Server secrets must NOT start with `VITE_`.
5. Set `VITE_USE_BACKEND=true`, add the Supabase public URL/key, and keep `VITE_DEV_PREMIUM=false`.
6. Use Paystack test keys first, make a test payment, and confirm Premium only activates after successful server-side verification. Switch to live keys only after all checks pass.
7. Test sign-up/sign-in, refresh, progress sync, AI access rules, payment success/failure, mobile layout and expired Premium.

## Source and question-bank note

The included questions are practice questions from the supplied app source, not official WAEC/NECO/JAMB past questions. Verify educational content before relying on it for an exam.
