# ExamHero Pro Terms — TEMPLATE

**This is a starting template, not legal advice. Replace bracketed items and obtain appropriate legal review before launch.**

Effective date: [DATE]
Operator: [LEGAL NAME / BUSINESS NAME]
Support: [SUPPORT EMAIL]

## Service and educational disclaimer
ExamHero Pro provides educational practice questions and study tools. Questions and AI explanations may contain errors and are not a guarantee of examination results. The included question bank is not represented as official WAEC, NECO or JAMB past papers. Check important answers against trusted learning materials.

## Accounts
Provide accurate information, protect your sign-in credentials and notify us if you believe your account has been accessed without permission. We may suspend abusive, fraudulent or unsafe use.

## Premium and payments
Premium plans currently displayed in the app are ₦1,500 for 30 days and ₦3,500 for 90 days. Confirm these prices, duration, taxes and availability before launch. Payment is processed by Paystack. Premium should only activate after successful server-side payment verification.

## Refunds and cancellation
[Publish a clear, lawful refund/cancellation policy here, including how to contact support and how accidental/duplicate payments are handled. Do not leave this section incomplete at launch.]

## Acceptable use
Do not misuse the service, attempt to access another person's data, abuse AI/payment endpoints, or interfere with availability or security.

## Availability and changes
Features may change and the service may occasionally be unavailable for maintenance. We will make reasonable efforts to protect saved data, but users should not rely on the service as their only copy of study records.

## Contact
Questions or complaints: [SUPPORT EMAIL / BUSINESS ADDRESS].
